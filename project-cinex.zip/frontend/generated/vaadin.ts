import './vaadin-featureflags.ts';

import './index';

import { applyTheme } from './theme';
applyTheme(document);
