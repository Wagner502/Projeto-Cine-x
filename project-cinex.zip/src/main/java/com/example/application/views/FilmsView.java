package com.example.application.views;

import com.example.application.backend.document.FilmDocument;
import com.example.application.backend.service.FilmService;
import com.example.application.components.button.ButtonCustom;
import com.example.application.components.dialog.DialogCustom;
import com.example.application.views.film.SelectSeatView;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouteAlias;

import static com.example.application.backend.util.GlobalUtil.buildFormattedDateString;

@PageTitle("Cartaz")
@Route(value = "cartaz", layout = MainLayout.class)
@RouteAlias(value = "", layout = MainLayout.class)
public class FilmsView extends HorizontalLayout {
    private final FilmService filmService;

    private DialogCustom dlgBuyTicket;

    public FilmsView(FilmService filmService) {
        this.filmService = filmService;

        getStyle().set("flex-wrap", "wrap");
        getStyle().set("justify-content", "center");

        createCards();
    }

    private void createCards() {
        var films = filmService.findAllFilmsByActiveTrue();

        films.forEach(film -> {
            VerticalLayout div = new VerticalLayout();
            div.setPadding(false);
            div.setSpacing(false);
            div.setAlignItems(Alignment.CENTER);
            div.getStyle().set("border", "1px solid #9e9e9e");
            div.getStyle().set("border-radius", "5px");
            div.getStyle().set("margin", "5px");
            div.getStyle().set("padding", "10px");
            div.getStyle().set("width", "");

            var urls = film.getUrlImage();
            Image img = new Image(urls.get(0), "filme");
            img.setWidth("350px");
            img.setMaxHeight("300px");
            div.add(img);

            H2 spnName = new H2(film.getName() + " - " + film.getDuration() + "min.");
            spnName.getStyle().set("font-weight", "bold");
            spnName.getStyle().set("margin", "0");
            spnName.getStyle().set("width", "100%");
            spnName.getStyle().set("text-align", "center");

            H4 spnDescription = new H4(film.getDescription());
            spnDescription.getStyle().set("font-weight", "400");
            spnDescription.getStyle().set("margin", "0");
            spnDescription.getStyle().set("width", "100%");
            spnDescription.getStyle().set("text-align", "center");

            Span spnDate = new Span("Em cartaz desde: " + buildFormattedDateString(film.getInitDate()) + " até " + buildFormattedDateString(film.getFinalDate()));
            Span spnPrice = new Span("R$ " + film.getPrice());
            spnPrice.getStyle().set("font-size", "20px");

            var sessions = film.getSession().split(";");
            StringBuilder sb = new StringBuilder();
            for (String session : sessions) {
                sb.append(session).append("hr ");
            }
            Span spnSession = new Span("Horários: " + sb);

            ButtonCustom btnSee = new ButtonCustom("Comprar ingresso");

            createButtonSee(btnSee, film);

            div.add(
                    spnName,
                    spnDescription,
                    spnPrice,
                    spnSession,
                    spnDate,
                    btnSee
            );

            add(div);
        });
    }

    private void createButtonSee(ButtonCustom btnSee, FilmDocument film) {
        btnSee.addClickListener(e -> {
            dlgBuyTicket = new DialogCustom("Selecionar assento", "Cancelar", "Confirmar");
            dlgBuyTicket.setSizeFull();
            dlgBuyTicket.open();

            SelectSeatView selectSeatView = new SelectSeatView(filmService, film, dlgBuyTicket);

            dlgBuyTicket.add(selectSeatView);
        });
    }

}
